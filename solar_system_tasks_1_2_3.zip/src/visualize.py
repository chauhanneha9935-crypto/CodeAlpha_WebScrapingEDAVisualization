import pandas as pd
import matplotlib.pyplot as plt

def visualize_data():
    df = pd.read_csv("data/processed/quotes_cleaned.csv")

    author_counts = df['author'].value_counts().head(10)

    plt.figure()
    author_counts.plot(kind='bar')
    plt.title("Top 10 Authors by Quote Count")
    plt.xlabel("Author")
    plt.ylabel("Number of Quotes")
    plt.tight_layout()
    plt.savefig("outputs/figures/top_authors.png")
    plt.show()

if __name__ == "__main__":
    visualize_data()
