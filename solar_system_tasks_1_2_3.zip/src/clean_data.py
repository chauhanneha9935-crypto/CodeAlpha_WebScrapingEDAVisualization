import pandas as pd

def clean_data():
    df = pd.read_csv("data/raw/quotes_raw.csv")
    df.drop_duplicates(inplace=True)
    df.dropna(inplace=True)
    df.to_csv("data/processed/quotes_cleaned.csv", index=False)
    print("Cleaning complete!")

if __name__ == "__main__":
    clean_data()
